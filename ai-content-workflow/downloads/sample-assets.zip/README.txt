Moss & Cotton workflow sample. Fictional product.
AI product and background images were pre-generated. Batch images are browser Canvas compositions. Video is a local still-image motion edit, not generative video. Review all assets before any commercial use.
